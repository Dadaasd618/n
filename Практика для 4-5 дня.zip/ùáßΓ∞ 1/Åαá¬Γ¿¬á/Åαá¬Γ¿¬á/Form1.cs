﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практика
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TestConnection()
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                var db = new Работа_индивидEntities2();
                var Tab = db.администрация.ToList();
                db.SaveChanges();
                MessageBox.Show("Подключение успешно");
            }
            catch
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var db = new Работа_индивидEntities2();

                //все данные из таблицы администрация
                var data = db.администрация.ToList();
                dataGridView1.DataSource = data;
            }
            catch
            {
                MessageBox.Show("Ошибка подключения");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                var db = new Работа_индивидEntities2();

                //количество записей в таблице администрация
                int col = db.администрация.Count();
                textBox1.Text = $"Количество администраторов: {col}";
            }
            catch
            {
                textBox1.Text = "Ошибка подключения";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                var db = new Работа_индивидEntities2();

                //имя первого администратора
                var name = db.администрация.OrderBy(a => a.id).Select(a => a.администратор).FirstOrDefault();
                label1.Text = name;
            }
            catch 
            {
                label1.Text = "Ошибка подключение";
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                var db = new Работа_индивидEntities2();

                //Вывод должностей таблицы
                var dolzen = db.администрация.Select(a => a.должность).ToList();
                listBox1.DataSource = dolzen;
            }
            catch
            {
                listBox1.Items.Add("Ошибка подключения");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                var db = new Работа_индивидEntities2();

                //Запрос всех имен
                listView1.Clear();
                listView1.View = View.List;
                var name1 = db.администрация.Select(a => a.администратор).ToList();

                foreach (var name in name1)
                {
                    listView1.Items.Add(name);
                }
            }
            catch
            {
                listView1.Items.Add("Ошибка подключения");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form2 newForm = new Form2();
            newForm.Show();
            this.Hide();
        }
    }
}
