﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практика
{

    public partial class Form4 : Form
    {
        private Работа_индивидEntities2 db;
        private readonly string backupFolder = @"C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS01\MSSQL\Backup";

        public Form4()
        {

            db = new Работа_индивидEntities2();
           
            InitializeComponent();


            Directory.CreateDirectory(backupFolder);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 newForm = new Form3();
            newForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Получаем информацию о базе данных
                string dbName = db.Database.Connection.Database;
                string backupName = $"{dbName}_Backup_{DateTime.Now:yyyyMMdd_HHmmss}.bak";
                string backupPath = Path.Combine(backupFolder, backupName);

                // Формируем команду BACKUP
                string backupCommand = $@"
                BACKUP DATABASE [{dbName}] 
                TO DISK = '{backupPath}' 
                WITH FORMAT, 
                     STATS = 5;";

                using (var connection = new SqlConnection(db.Database.Connection.ConnectionString))
                {
                    connection.Open();

                    using (var command = new SqlCommand(backupCommand, connection))
                    {
                        // Выводим сообщение о начале процесса
                        MessageBox.Show("Начато создание резервной копии...",
                                     "Резервное копирование",
                                     MessageBoxButtons.OK,
                                     MessageBoxIcon.Information);

                        // Выполняем команду
                        command.CommandTimeout = 600; // 10 минут на выполнение
                        command.ExecuteNonQuery();

                        // Сообщение об успешном завершении
                        MessageBox.Show($"Резервная копия успешно создана:\n{backupPath}",
                                      "Успех",
                                      MessageBoxButtons.OK,
                                      MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"Ошибка SQL при создании резервной копии:\n{sqlEx.Message}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }

        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            db.Dispose();
            base.OnFormClosing(e);
        }


        private void Form4_FormClosed_1(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }

}
