﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практика
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string password = textBox1.Text;

            // Проверяем пароль по правилам
            if (password.Length < 6)
            {
                MessageBox.Show("Пароль слишком короткий, нужно минимум 6 символов");
                return;
            }

            var bykv = false;
            foreach (char c in password)
            {
                if (char.IsLetter(c))
                {
                    bykv = true;
                    break;
                }
            }
            if (!bykv)
            {
                MessageBox.Show("Добавьте хотя бы одну букву");
                return;
            }

            var cifr = false;
            foreach (char c in password)
            {
                if (char.IsDigit(c))
                {
                    cifr = true;
                    break;
                }
            }

            if (!cifr)
            {
                MessageBox.Show("Добавьте хотя бы одну цифру");
                return;
            }

            // Если все проверки пройдены
            MessageBox.Show("Пароль подходит");
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 newForm = new Form1();
            newForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 newForm = new Form3();
            newForm.Show();
            this.Hide();
        }
    }
}
