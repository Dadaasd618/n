﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace Практика
{
    public partial class Form3 : Form
    {
        int vrema = 0;
        DateTime blockTime = DateTime.MinValue;
        string lockFile = "lock.txt";
        bool isAuthorized = false;

        public Form3()
        {

            InitializeComponent();
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            button2.Enabled = false;
            if (File.Exists(lockFile))
            {
                string timeText = File.ReadAllText(lockFile);
                if (DateTime.TryParse(timeText, out blockTime) && blockTime > DateTime.Now)
                {
                    StartBlock();
                }
                else
                {
                    File.Delete(lockFile);
                }
            }

            }

        private void button1_Click(object sender, EventArgs e)
        {
            var db = new Работа_индивидEntities2();
            var Tab = db.Информационные_система.ToList();
            if (IsBlocked())
            {
                MessageBox.Show($"Система заблокирована. Осталось: {(blockTime - DateTime.Now):mm\\:ss}");
                return;
            }

            if (Check(textBox1.Text, textBox2.Text))
            {
                MessageBox.Show("Авторизация успешна!");
                vrema = 0;
                isAuthorized = true;
                button2.Enabled = true;
            }
            else
            {
                vrema++;
                if (vrema >= 3)
                {
                    blockTime = DateTime.Now.AddMinutes(5);
                    File.WriteAllText(lockFile, blockTime.ToString());
                    StartBlock();
                    MessageBox.Show("Система заблокирована на 5 минут!");
                    button2.Enabled = false;
                }
                else
                {
                    MessageBox.Show($"Неверный логин/пароль. Осталось попыток: {3 - vrema}");
                }

            }

        }
        bool IsBlocked() => blockTime > DateTime.Now;

        bool Check(string login, string password)
        {
            try
            {
                using (var db = new Работа_индивидEntities2())
                {
                    return db.Информационные_система.Any(u => u.Имя == login && u.Пароль == password);
                }
            }
            catch
            {
                MessageBox.Show("Ошибка подключения к базе данных");
                return false;
            }
        }

        void StartBlock()
        {
            timer1.Start();
            button1.Enabled = false;
            button2.Enabled = false;
            UpdateTimerLabel(); // Немедленное обновление
        }


        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UpdateTimerLabel();
        
        }
        private void UpdateTimerLabel()
        {
            if (IsBlocked())
            {
                TimeSpan remaining = blockTime - DateTime.Now;
                label3.Text = $"Блокировка: {remaining:mm\\:ss}";
                label3.Refresh(); // Принудительное обновление
            }
            else
            {
                timer1.Stop();
                label3.Text = "";
                button1.Enabled = true;
                if (File.Exists(lockFile))
                    File.Delete(lockFile);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 newForm = new Form2();
            newForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 newForm = new Form4();
            newForm.Show();
            this.Hide();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

    }
    }

